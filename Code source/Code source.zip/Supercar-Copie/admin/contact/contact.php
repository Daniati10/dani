<?php 
// Inclure le fichier de configuration
include_once($_SERVER['DOCUMENT_ROOT'] . "/supercar/admin/config.php");

// Vérifiez la connexion
if (!$bdd) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

// Récupérer les données de la table `form` par ordre croissant d'ID
$result = mysqli_query($bdd, "SELECT * FROM form ORDER BY id ASC");

if (!$result) {
    die("Erreur dans la requête SQL : " . mysqli_error($bdd));
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des contacts</title>
    <style>
        /* Styles pour centrer le contenu */
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }

        /* Styles pour le paragraphe */
        p {
            margin-bottom: 20px;
            font-weight: bold;
            font-size: 1.5em;
            text-align: center;
        }

        /* Styles pour le tableau */
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 0 auto;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        th {
            padding-top: 12px;
            padding-bottom: 12px;
            background-color: #4CAF50;
            color: white;
        }

        /* Lien retour */
        a {
            margin-top: 20px;
            text-decoration: none;
            font-weight: bold;
            color: #4CAF50;
        }

        a:hover {
            color: #388E3C;
        }
    </style>
</head>

<body>
    <p>Gestion des contacts</p>

    <table>
        <tr bgcolor="#CCCCCC">
            <th>ID</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Objet</th>
            <th>Message</th>
            <th>Actions</th>
        </tr>

        <?php 
        // Parcourir les résultats et afficher les données dans le tableau
        while ($res = mysqli_fetch_assoc($result)) {         
            echo "<tr>";
            echo "<td>".$res['id']."</td>";
            echo "<td>".$res['nom']."</td>";
            echo "<td>".$res['email']."</td>";
            echo "<td>".$res['objet']."</td>";
            echo "<td>".$res['massage']."</td>";
            echo "<td>
                    <a href=\"edits.php?id=".$res['id']."\">Modifier</a> |
                    <a href=\"deletes.php?id=".$res['id']."\" onClick=\"return confirm('Êtes-vous sûr de vouloir supprimer ?')\">Supprimer</a>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>

    <a href="/supercar/dashboard.php">Retour</a>
</body>
</html>
