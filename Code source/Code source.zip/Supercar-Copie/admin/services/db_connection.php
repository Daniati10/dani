<?php
// Configuration des paramètres de connexion à la base de données
$host = 'localhost';
$dbname = 'supercar';
$username = 'root';
$password = '';

try {
    // Création de l'objet PDO pour la connexion à la base de données
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

    // Configuration du mode d'erreur pour PDO
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // En cas d'erreur de connexion, afficher un message et arrêter le script
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>
