<?php

// Inclure la connexion à la base de données
require_once 'db_connection.php';

// Gestion des données soumises par le formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['update'])) {
    // Récupérer les données du formulaire d'ajout
    $type = $_POST['type'];
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $date_fin = $_POST['date_fin'];
    $reduction = $_POST['reduction'];

    // Préparation et exécution de la requête d'insertion pour la promotion
    $query = $db->prepare("INSERT INTO promotions (type, titre, description, date_fin, reduction) 
                           VALUES (?, ?, ?, ?, ?)");
    $query->execute([$type, $titre, $description, $date_fin, $reduction]);

    // Message de confirmation
    $_SESSION['message'] = "Promotion ajoutée avec succès.";
    // Redirection pour éviter la soumission multiple
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la suppression d'une promotion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id_promotion = $_GET['delete'];

    // Préparation et exécution de la requête de suppression
    $query = $db->prepare("DELETE FROM promotions WHERE id = ?");
    $query->execute([$id_promotion]);

    // Message de confirmation
    $_SESSION['message'] = "Promotion supprimée avec succès.";
    // Redirection après suppression
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la mise à jour d'une promotion
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $id_promotion = $_GET['edit'];

    // Récupérer les informations de la promotion pour l'afficher dans le formulaire
    $query = $db->prepare("SELECT * FROM promotions WHERE id = ?");
    $query->execute([$id_promotion]);
    $promotion = $query->fetch();

    if (!$promotion) {
        $_SESSION['message'] = "Promotion introuvable.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Mise à jour de la promotion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $id = $_POST['id'];  // ID de la promotion
    $type = $_POST['type'];
    $titre = $_POST['titre'];
    $description = $_POST['description'];
    $date_fin = $_POST['date_fin'];
    $reduction = $_POST['reduction'];

    // Mise à jour de la promotion
    $query = $db->prepare("UPDATE promotions SET type = ?, titre = ?, description = ?, date_fin = ?, reduction = ? WHERE id = ?");
    $query->execute([$type, $titre, $description, $date_fin, $reduction, $id]);

    // Message de confirmation
    $_SESSION['message'] = "Promotion mise à jour avec succès.";
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Récupérer toutes les promotions existantes
$query = $db->query("SELECT * FROM promotions");
$promotions = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer Promotions</title>

    <style>/* Styles généraux */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

h1, h2 {
    color: #333;
    margin-bottom: 20px;
    text-align: center;
}

.container {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 800px;
    margin-bottom: 20px;
}

/* Styles pour les tables */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

table th, table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}

table th {
    background-color: #f0f0f5;
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
}

/* Styles pour les boutons */
.btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: rgb(0, 0, 0);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
    transition: background-color 0.3s;
    text-align: center;
}

.btn:hover {
    background-color: rgb(255, 0, 0);
}

button {
    width: 100%;
    padding: 12px;
    background-color: rgb(0, 0, 0);
    border: none;
    border-radius: 5px;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: rgb(255, 0, 0);
}

/* Formulaire de connexion */
.login-container {
    background-color: #ffffff;
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
    margin: 20px auto;
}

.login-container label {
    display: block;
    font-size: 14px;
    margin-bottom: 5px;
    text-align: left;
    margin-left: 10px;
}

.login-container input {
    width: 100%;
    padding: 12px;
    margin: 10px 0 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 16px;
}

.error-message {
    color: red;
    margin-bottom: 20px;
}

/* Lien stylé */
a {
    color: black;
    text-decoration: none;
    font-size: 14px;
}

a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
    <h3>Promotions Existantes</h3>
    <table>
        <thead>
            <tr>
                <th>Type</th>
                <th>Titre</th>
                <th>Description</th>
                <th>Date de Fin</th>
                <th>Réduction (%)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($promotions as $promotion): ?>
                <tr>
                    <td><?php echo htmlspecialchars($promotion['type']); ?></td>
                    <td><?php echo htmlspecialchars($promotion['titre']); ?></td>
                    <td><?php echo htmlspecialchars($promotion['description']); ?></td>
                    <td><?php echo htmlspecialchars($promotion['date_fin']); ?></td>
                    <td><?php echo htmlspecialchars($promotion['reduction']); ?>%</td>
                    <td>
                        <a href="?edit=<?php echo $promotion['id']; ?>"><button>Modifier</button></a>
                        <a href="?delete=<?php echo $promotion['id']; ?>" onclick="return confirm('Voulez-vous vraiment supprimer cette promotion ?');">
                            <button class="btn-delete">Supprimer</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php
    // Si un ID de promotion est passé pour modification
    if (isset($_GET['edit'])) {
        $id_promotion = $_GET['edit'];

        // Récupérer les détails de la promotion à modifier
        $query = $db->prepare("SELECT * FROM promotions WHERE id = ?");
        $query->execute([$id_promotion]);
        $promotion = $query->fetch();

        // Si la promotion existe, afficher le formulaire pré-rempli
        if ($promotion) {
            ?>
            <h3>Modifier la Promotion</h3>
            <form action="" method="POST">
                <input type="hidden" name="id" value="<?php echo $promotion['id']; ?>">

                <label for="type">Type :</label>
                <input type="text" name="type" id="type" value="<?php echo htmlspecialchars($promotion['type']); ?>" required>

                <label for="titre">Titre :</label>
                <input type="text" name="titre" id="titre" value="<?php echo htmlspecialchars($promotion['titre']); ?>" required>

                <label for="description">Description :</label>
                <textarea name="description" id="description" required><?php echo htmlspecialchars($promotion['description']); ?></textarea>

                <label for="date_fin">Date de fin :</label>
                <input type="date" name="date_fin" id="date_fin" value="<?php echo htmlspecialchars($promotion['date_fin']); ?>" required>

                <label for="reduction">Réduction :</label>
                <input type="number" name="reduction" id="reduction" value="<?php echo htmlspecialchars($promotion['reduction']); ?>" required>

                <button type="submit" name="update" class="btn-primary">Mettre à jour la promotion</button>
            </form>
            <?php
        }
    }
    ?>

    <h3>Ajouter une Nouvelle Promotion</h3>
    <form action="" method="POST">
        <label for="type">Type :</label>
        <input type="text" name="type" id="type" required>

        <label for="titre">Titre :</label>
        <input type="text" name="titre" id="titre" required>

        <label for="description">Description :</label>
        <textarea name="description" id="description" required></textarea>

        <label for="date_fin">Date de fin :</label>
        <input type="date" name="date_fin" id="date_fin" required>

        <label for="reduction">Réduction :</label>
        <input type="number" name="reduction" id="reduction" required>

        <button type="submit" class="btn-primary">Ajouter la promotion</button> |
        <button type="button" onclick="window.location.href='services_dashboard.php';">Retour</button>
    </form>
    
</body>
</html>
