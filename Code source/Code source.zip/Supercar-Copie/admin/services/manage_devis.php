<?php



// Inclure la connexion à la base de données
require_once 'db_connection.php';

// Gestion des données soumises par le formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['update'])) {
    // Récupérer les données du formulaire d'ajout
    $sexe = $_POST['sexe'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $telephone = $_POST['telephone'];
    $mail = $_POST['mail'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $code_postal = $_POST['code_postal'];
    $voiture = $_POST['voiture'];

    // Préparation et exécution de la requête d'insertion pour la demande de devis
    $query = $db->prepare("INSERT INTO demande_de_devis (sexe, nom, prenom, telephone, mail, adresse, ville, code_postal, voiture) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $query->execute([$sexe, $nom, $prenom, $telephone, $mail, $adresse, $ville, $code_postal, $voiture]);

    // Redirection pour éviter la soumission multiple
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la mise à jour d'une demande de devis
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $id = $_POST['id'];
    $sexe = $_POST['sexe'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $telephone = $_POST['telephone'];
    $mail = $_POST['mail'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $code_postal = $_POST['code_postal'];
    $voiture = $_POST['voiture'];

    // Préparation et exécution de la requête de mise à jour
    $query = $db->prepare("UPDATE demande_de_devis SET sexe = ?, nom = ?, prenom = ?, telephone = ?, mail = ?, adresse = ?, ville = ?, code_postal = ?, voiture = ? WHERE id = ?");
    $query->execute([$sexe, $nom, $prenom, $telephone, $mail, $adresse, $ville, $code_postal, $voiture, $id]);

    // Redirection pour éviter la soumission multiple et actualiser la page
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la suppression d'une demande de devis
if (isset($_GET['delete'])) {
    $id_demande = $_GET['delete'];

    // Préparation et exécution de la requête de suppression
    $query = $db->prepare("DELETE FROM demande_de_devis WHERE id = ?");
    $query->execute([$id_demande]);

    // Redirection après suppression
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Récupérer toutes les demandes de devis existantes
$query = $db->query("SELECT * FROM demande_de_devis");
$demande_de_devis = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer Demande de Devis</title>
    <style>/* Styles généraux */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

h1, h2 {
    color: #333;
    margin-bottom: 20px;
    text-align: center;
}

.container {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 800px;
    margin-bottom: 20px;
}

/* Styles pour les tables */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

table th, table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}

table th {
    background-color: #f0f0f5;
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
}

/* Styles pour les boutons */
.btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: rgb(0, 0, 0);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
    transition: background-color 0.3s;
    text-align: center;
}

.btn:hover {
    background-color: rgb(255, 0, 0);
}

button {
    width: 100%;
    padding: 12px;
    background-color: rgb(0, 0, 0);
    border: none;
    border-radius: 5px;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: rgb(255, 0, 0);
}

/* Formulaire de connexion */
.login-container {
    background-color: #ffffff;
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
    margin: 20px auto;
}

.login-container label {
    display: block;
    font-size: 14px;
    margin-bottom: 5px;
    text-align: left;
    margin-left: 10px;
}

.login-container input {
    width: 100%;
    padding: 12px;
    margin: 10px 0 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 16px;
}

.error-message {
    color: red;
    margin-bottom: 20px;
}

/* Lien stylé */
a {
    color: black;
    text-decoration: none;
    font-size: 14px;
}

a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
    <h2>Gérer Demandes de Devis</h2>

    <!-- Tableau pour afficher les demandes de devis existantes -->
    <h3>Demandes de Devis Existantes</h3>
    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Sexe</th>
                <th>Voiture</th>
                <th>Téléphone</th>
                <th>E-mail</th>
                <th>Adresse</th>
                <th>Ville</th>
                <th>Code Postal</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($demande_de_devis as $demande): ?>
                <tr>
                    <td><?php echo htmlspecialchars($demande['nom']); ?></td>
                    <td><?php echo htmlspecialchars($demande['prenom']); ?></td>
                    <td><?php echo htmlspecialchars($demande['sexe']); ?></td>
                    <td><?php echo htmlspecialchars($demande['voiture']); ?></td>
                    <td><?php echo htmlspecialchars($demande['telephone']); ?></td>
                    <td><?php echo htmlspecialchars($demande['mail']); ?></td>
                    <td><?php echo htmlspecialchars($demande['adresse']); ?></td>
                    <td><?php echo htmlspecialchars($demande['ville']); ?></td>
                    <td><?php echo htmlspecialchars($demande['code_postal']); ?></td>
                    <td>
                        <!-- Bouton Modifier qui redirige vers la page de modification -->
                        <a href="?edit=<?php echo $demande['id']; ?>">
                            <button>Modifier</button>
                        </a>
                        <!-- Bouton Supprimer qui redirige vers la suppression -->
                        <a href="?delete=<?php echo $demande['id']; ?>" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette demande ?');">
                            <button class="btn-delete">Supprimer</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php
    // Si un ID de demande est passé pour modification
    if (isset($_GET['edit'])) {
        $id_demande = $_GET['edit'];

        // Récupérer les détails de la demande de devis à modifier
        $query = $db->prepare("SELECT * FROM demande_de_devis WHERE id = ?");
        $query->execute([$id_demande]);
        $demande = $query->fetch();

        // Si la demande existe, afficher le formulaire pré-rempli
        if ($demande) {
            ?>
            <h3>Modifier la Demande de Devis</h3>
            <form action="" method="POST">
                <input type="hidden" name="id" value="<?php echo $demande['id']; ?>">

                <label for="sexe">Sexe :</label>
                <select name="sexe" id="sexe" required>
                    <option value="Homme" <?php echo ($demande['sexe'] == 'Homme') ? 'selected' : ''; ?>>Homme</option>
                    <option value="Femme" <?php echo ($demande['sexe'] == 'Femme') ? 'selected' : ''; ?>>Femme</option>
                </select>

                <label for="nom">Nom :</label>
                <input type="text" name="nom" id="nom" value="<?php echo htmlspecialchars($demande['nom']); ?>" required>

                <label for="prenom">Prénom :</label>
                <input type="text" name="prenom" id="prenom" value="<?php echo htmlspecialchars($demande['prenom']); ?>" required>

                <label for="telephone">Téléphone :</label>
                <input type="text" name="telephone" id="telephone" value="<?php echo htmlspecialchars($demande['telephone']); ?>" required>

                <label for="mail">E-mail :</label>
                <input type="email" name="mail" id="mail" value="<?php echo htmlspecialchars($demande['mail']); ?>" required>

                <label for="adresse">Adresse :</label>
                <input type="text" name="adresse" id="adresse" value="<?php echo htmlspecialchars($demande['adresse']); ?>" required>

                <label for="ville">Ville :</label>
                <input type="text" name="ville" id="ville" value="<?php echo htmlspecialchars($demande['ville']); ?>" required>

                <label for="code_postal">Code postal :</label>
                <input type="text" name="code_postal" id="code_postal" value="<?php echo htmlspecialchars($demande['code_postal']); ?>" required>

                <label for="voiture">Voiture :</label>
                <select name="voiture" id="voiture" required>
                    <option value="Ferrari" <?php echo ($demande['voiture'] == 'Ferrari') ? 'selected' : ''; ?>>Ferrari</option>
                    <option value="McLarren" <?php echo ($demande['voiture'] == 'McLarren') ? 'selected' : ''; ?>>McLarren</option>
                    <option value="Porche" <?php echo ($demande['voiture'] == 'Porche') ? 'selected' : ''; ?>>Porche</option>
                    <option value="Maseratti" <?php echo ($demande['voiture'] == 'Maseratti') ? 'selected' : ''; ?>>Maseratti</option>
                </select>

                <button type="submit" name="update" class="btn-primary">Mettre à jour la Demande de Devis</button>
            </form>
            <?php
        }
    }
    ?>

    <!-- Formulaire pour ajouter une nouvelle demande de devis -->
    <h3>Ajouter une Demande de Devis</h3>
    <form action="" method="POST" class="form-container">
        <label for="sexe">Sexe :</label>
        <select name="sexe" id="sexe" required>
            <option value="Homme">Homme</option>
            <option value="Femme">Femme</option>
        </select>

        <label for="nom">Nom :</label>
        <input type="text" name="nom" id="nom" required>

        <label for="prenom">Prénom :</label>
        <input type="text" name="prenom" id="prenom" required>

        <label for="telephone">Téléphone :</label>
        <input type="text" name="telephone" id="telephone" required>

        <label for="mail">E-mail :</label>
        <input type="email" name="mail" id="mail" required>

        <label for="adresse">Adresse :</label>
        <input type="text" name="adresse" id="adresse" required>

        <label for="ville">Ville :</label>
        <input type="text" name="ville" id="ville" required>

        <label for="code_postal">Code postal :</label>
        <input type="text" name="code_postal" id="code_postal" required>

        <label for="voiture">Voiture :</label>
        <select name="voiture" id="voiture" required>
            <option value="Ferrari">Ferrari</option>
            <option value="McLarren">McLarren</option>
            <option value="Porche">Porche</option>
            <option value="Maseratti">Maseratti</option>
        </select>

        <button type="submit" class="btn-primary">Ajouter une Demande de Devis</button> |
        <button type="button" onclick="window.location.href='services_dashboard.php';">Retour</button>
    </form>
    
</body>
</html>
