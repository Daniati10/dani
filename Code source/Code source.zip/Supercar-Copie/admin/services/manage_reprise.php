<?php


// Inclure la connexion à la base de données
require_once 'db_connection.php';

// Fonction pour assainir les données utilisateur
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Gestion des données soumises par le formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['update'])) {
    // Récupérer et assainir les données du formulaire d'ajout
    $marque = sanitize_input($_POST['marque']);
    $modele = sanitize_input($_POST['modele']);
    $annee = sanitize_input($_POST['annee']);
    $kilometrage = sanitize_input($_POST['kilometrage']);
    $etat = sanitize_input($_POST['etat']);
    $mail = sanitize_input($_POST['mail']);

    // Préparation et exécution de la requête d'insertion pour le véhicule repris
    $query = $db->prepare("INSERT INTO reprise_vehicules (marque, modele, annee, kilometrage, etat, mail) 
                           VALUES (?, ?, ?, ?, ?, ?)");
    $query->execute([$marque, $modele, $annee, $kilometrage, $etat, $mail]);

    // Message de confirmation
    $_SESSION['message'] = "Véhicule repris ajouté avec succès.";
    // Redirection pour éviter la soumission multiple
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la suppression d'un véhicule repris
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id_vehicule = $_GET['delete'];

    // Préparation et exécution de la requête de suppression
    $query = $db->prepare("DELETE FROM reprise_vehicules WHERE id = ?");
    $query->execute([$id_vehicule]);

    // Message de confirmation
    $_SESSION['message'] = "Véhicule supprimé avec succès.";
    // Redirection après suppression
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la mise à jour d'un véhicule repris
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $id_vehicule = $_GET['edit'];

    // Récupérer les informations du véhicule pour l'afficher dans le formulaire
    $query = $db->prepare("SELECT * FROM reprise_vehicules WHERE id = ?");
    $query->execute([$id_vehicule]);
    $vehicule = $query->fetch();

    if (!$vehicule) {
        $_SESSION['message'] = "Véhicule introuvable.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Mise à jour du véhicule repris
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    // Assainir et récupérer les données pour la mise à jour
    $id = sanitize_input($_POST['id']);
    $marque = sanitize_input($_POST['marque']);
    $modele = sanitize_input($_POST['modele']);
    $annee = sanitize_input($_POST['annee']);
    $kilometrage = sanitize_input($_POST['kilometrage']);
    $etat = sanitize_input($_POST['etat']);
    $mail = sanitize_input($_POST['mail']);

    // Mise à jour du véhicule
    $query = $db->prepare("UPDATE reprise_vehicules SET marque = ?, modele = ?, annee = ?, kilometrage = ?, etat = ?, mail = ? WHERE id = ?");
    $query->execute([$marque, $modele, $annee, $kilometrage, $etat, $mail, $id]);

    // Message de confirmation
    $_SESSION['message'] = "Véhicule mis à jour avec succès.";
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Récupérer tous les véhicules repris
$query = $db->query("SELECT * FROM reprise_vehicules");
$vehicules = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer Véhicules Repris</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        /* Styles pour les tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Styles pour les boutons */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn:hover {
            background-color: rgb(255, 0, 0);
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(255, 0, 0);
        }

        /* Formulaire de connexion */
        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin: 20px auto;
        }

        .login-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        /* Lien stylé */
        a {
            color: black;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h3>Véhicules Repris</h3>
    <table>
        <thead>
            <tr>
                <th>Marque</th>
                <th>Modèle</th>
                <th>Année</th>
                <th>Kilométrage</th>
                <th>État</th>
                <th>Mail</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($vehicules as $vehicule): ?>
                <tr>
                    <td><?php echo htmlspecialchars($vehicule['marque']); ?></td>
                    <td><?php echo htmlspecialchars($vehicule['modele']); ?></td>
                    <td><?php echo htmlspecialchars($vehicule['annee']); ?></td>
                    <td><?php echo htmlspecialchars($vehicule['kilometrage']); ?> km</td>
                    <td><?php echo htmlspecialchars($vehicule['etat']); ?></td>
                    <td><?php echo htmlspecialchars($vehicule['mail']); ?></td>
                    <td>
                        <a href="?edit=<?php echo $vehicule['id']; ?>"><button>Modifier</button></a>
                        <a href="?delete=<?php echo $vehicule['id']; ?>" onclick="return confirm('Voulez-vous vraiment supprimer ce véhicule ?');">
                            <button class="btn">Supprimer</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php
    // Si un ID de véhicule est passé pour modification
    if (isset($_GET['edit'])) {
        $id_vehicule = $_GET['edit'];

        // Récupérer les détails du véhicule à modifier
        $query = $db->prepare("SELECT * FROM reprise_vehicules WHERE id = ?");
        $query->execute([$id_vehicule]);
        $vehicule = $query->fetch();

        // Si le véhicule existe, afficher le formulaire pré-rempli
        if ($vehicule) {
            ?>
            <h3>Modifier le Véhicule</h3>
            <form action="" method="POST">
                <input type="hidden" name="id" value="<?php echo $vehicule['id']; ?>">

                <label for="marque">Marque :</label>
                <input type="text" name="marque" id="marque" value="<?php echo htmlspecialchars($vehicule['marque']); ?>" required>

                <label for="modele">Modèle :</label>
                <input type="text" name="modele" id="modele" value="<?php echo htmlspecialchars($vehicule['modele']); ?>" required>

                <label for="annee">Année :</label>
                <input type="number" name="annee" id="annee" value="<?php echo htmlspecialchars($vehicule['annee']); ?>" required>

                <label for="kilometrage">Kilométrage :</label>
                <input type="number" name="kilometrage" id="kilometrage" value="<?php echo htmlspecialchars($vehicule['kilometrage']); ?>" required>

                <label for="etat">État :</label>
                <select name="etat" id="etat" required>
                    <option value="excellent" <?php echo $vehicule['etat'] == 'excellent' ? 'selected' : ''; ?>>Excellent</option>
                    <option value="bon" <?php echo $vehicule['etat'] == 'bon' ? 'selected' : ''; ?>>Bon</option>
                    <option value="moyen" <?php echo $vehicule['etat'] == 'moyen' ? 'selected' : ''; ?>>Moyen</option>
                    <option value="mauvais" <?php echo $vehicule['etat'] == 'mauvais' ? 'selected' : ''; ?>>Mauvais</option>
                </select>

                <label for="mail">Mail :</label>
                <input type="text" name="mail" id="mail" value="<?php echo htmlspecialchars($vehicule['mail']); ?>" required>

                <button type="submit" name="update" class="btn">Mettre à jour le véhicule</button>
            </form>
            <?php
        }
    }
    ?>

    <h3>Ajouter un Nouveau Véhicule Repris</h3>
    <form action="" method="POST">
        <label for="marque">Marque :</label>
        <input type="text" name="marque" id="marque" required>

        <label for="modele">Modèle :</label>
        <input type="text" name="modele" id="modele" required>

        <label for="annee">Année :</label>
        <input type="number" name="annee" id="annee" required>

        <label for="kilometrage">Kilométrage :</label>
        <input type="number" name="kilometrage" id="kilometrage" required>

        <label for="etat">État :</label>
        <select name="etat" id="etat" required>
            <option value="excellent">Excellent</option>
            <option value="bon">Bon</option>
            <option value="moyen">Moyen</option>
            <option value="mauvais">Mauvais</option>
        </select>

        <label for="mail">Mail :</label>
        <input type="text" name="mail" id="mail" required>

        <button type="submit" class="btn">Ajouter le véhicule</button>
        <button type="button" onclick="window.location.href='services_dashboard.php';">Retour</button>
    </form>
</body>
</html>
