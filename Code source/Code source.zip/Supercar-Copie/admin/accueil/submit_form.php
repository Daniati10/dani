<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $date = $_POST['date'];
    $heure = $_POST['heure'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];
    $commentaire = $_POST['commentaire'];

    // Connexion à la base de données
    $conn = new mysqli('localhost', 'root', '', 'supercar');
    if ($conn->connect_error) {
        die("Erreur de connexion : " . $conn->connect_error);
    }

    // Insertion dans la table
    $stmt = $conn->prepare("INSERT INTO demandes_essai (user_id, marque, modele, date, heure, telephone, email, commentaire) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssss", $user_id, $marque, $modele, $date, $heure, $telephone, $email, $commentaire);

    if ($stmt->execute()) {
        // Affiche un message et redirige après 5 secondes
        echo "<div style='text-align: center; margin-top: 20%; font-family: Arial, sans-serif;'>
                <h1 style='color: green;'>Demande envoyée avec succès !</h1>
                <p>Vous serez redirigé dans 5 secondes...</p>
              </div>";
        echo "<script>
                setTimeout(function() {
                    window.location.href = 'demandes_essai.php';
                }, 5000);
              </script>";
    } else {
        echo "<div style='text-align: center; margin-top: 20%; font-family: Arial, sans-serif;'>
                <h1 style='color: red;'>Erreur : " . htmlspecialchars($stmt->error) . "</h1>
                <p>Veuillez réessayer.</p>
              </div>";
    }

    $stmt->close();
    $conn->close();
}
?>
