<?php
// Informations de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supercar";

// Créer une connexion
$bdd = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($bdd->connect_error) {
    die("Connexion échouée : " . $bdd->connect_error);
}

// Encodage des données en UTF-8 (important pour les accents)
$bdd->set_charset("utf8");

// Liste des adresses IP interdites
$blacklist = [
    '192.168.1.100', // Exemple d'IP
    '203.0.113.45',
    '93.190.142.103'
];

// Récupération de l'adresse IP du client
$user_ip = $_SERVER['REMOTE_ADDR'];

// Vérification si l'adresse IP est dans la blacklist
if (in_array($user_ip, $blacklist)) {
    // Bloquer l'accès
    header('HTTP/1.0 403 Forbidden');
    echo "<h1>403 Accès interdit</h1>";
    echo "Votre adresse IP a été blacklistée.";
    exit;
}
?>
