<?php 

//including the database connection file
include_once($_SERVER['DOCUMENT_ROOT'] . "/supercar/admin/config.php");
 
//getting id of the data from url
$id = $_GET['id'];
 
//deleting the row from table
$result = mysqli_query($bdd, "DELETE FROM demandes_essai WHERE id=$id");

//redirecting to the display page (index.php in our case)
header("Location:index.php");

?>