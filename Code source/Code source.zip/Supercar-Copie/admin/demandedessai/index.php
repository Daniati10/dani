<?php
// Inclusion de la connexion à la base de données
include_once($_SERVER['DOCUMENT_ROOT'] . "/supercar/admin/config.php");

// Vérification si la connexion est établie
if (!$bdd) {
    die("<p style='color: red;'>Erreur de connexion à la base de données : " . mysqli_connect_error() . "</p>");
}

// Récupération des données de la table "demandes_essai" par ordre croissant d'ID
$query = "SELECT * FROM demandes_essai ORDER BY id ASC";
$result = mysqli_query($bdd, $query);

if (!$result) {
    die("<p style='color: red;'>Erreur lors de la récupération des données : " . mysqli_error($bdd) . "</p>");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Demandes</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }
        table {
            border-collapse: collapse;
            width: 90%;
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            padding: 12px;
            background-color: #4CAF50;
            color: white;
        }
        .btn {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            color: white;
            border-radius: 4px;
            margin: 0 2px;
        }
        .btn-confirm { background-color: #28a745; }
        .btn-complete { background-color: #007bff; }
        .btn-cancel { background-color: #dc3545; }
    </style>
</head>

<body>
    <p>Gestion des Demandes</p>

    <table>
        <tr>
            <th>ID</th>
            <th>Marque</th>
            <th>Modèle</th>
            <th>Téléphone</th>
            <th>Email</th>
            <th>Commentaires</th>
            <th>Statut</th>
            <th>Action</th>
        </tr>

        <?php 
        while ($res = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($res['id']) . "</td>";
            echo "<td>" . htmlspecialchars($res['marque']) . "</td>";
            echo "<td>" . htmlspecialchars($res['modele']) . "</td>";
            echo "<td>" . htmlspecialchars($res['telephone']) . "</td>";
            echo "<td>" . htmlspecialchars($res['email']) . "</td>";
            echo "<td>" . htmlspecialchars($res['commentaire']) . "</td>";
            echo "<td id='status-" . $res['id'] . "'>" . htmlspecialchars($res['statut']) . "</td>";
            echo "<td>
                    <a href='edit.php?id=" . htmlspecialchars($res['id']) . "'>Modifier</a> | 
                    <a href='delete.php?id=" . htmlspecialchars($res['id']) . "' onClick=\"return confirm('Êtes-vous sûr de vouloir supprimer cette demande ?')\">Supprimer</a>
                    <br>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>

    <br>
    <a href="/supercar/dashboard.php">Retour</a>

    <script>
        function updateStatus(id, statut) {
            fetch('demandedessai/update_statuts.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + id + '&statut=' + statut
            })
            .then(response => response.text())
            .then(data => {
                if (data === "success") {
                    document.getElementById('status-' + id).innerText = statut;
                } else {
                    alert("Erreur lors de la mise à jour du statut.");
                }
            });
        }
    </script>
</body>
</html>
