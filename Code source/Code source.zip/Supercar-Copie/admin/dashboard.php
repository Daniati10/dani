<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
?>


<style>
    /* Styles pour agrandir les cases */
    table {
        border-collapse: collapse; /* Supprime les espaces entre les bordures */
        width: 80%; /* Ajuste la largeur du tableau */
        margin: auto; /* Centre le tableau sur la page */
        margin-top: 100px;
    }

    td {
        width: 33.33%; /* Divise également la largeur entre les colonnes */
        height: 300px; /* Ajuste la hauteur des cases */
        text-align: center; /* Centre le contenu horizontalement */
        vertical-align: middle; /* Centre le contenu verticalement */
        font-size: 30px; /* Augmente la taille de la police */
        border: 1px solid black; /* Ajoute une bordure visible */
    }

    /* Optionnel : Ajout d'un style au survol des cases */
    td:hover {
        background-color: #f0f0f0; /* Change la couleur de fond au survol */
        cursor: pointer; /* Change le curseur au survol */
    }
</style>
<a href="deconnexion.php" class="btn btn-red-500">Déconnexion</a>


<table border="1" style="">
    <tr>
        <td><a href="./accueil/index.php" style="">Accueil</a></td>
        <td><a href="./demandedessai/index.php" style="">Demande d'essai</a></td>
        <td><a href="./voitures/index.php" style="">Voitures</a></td>
    </tr>
    <tr>
        <td><a href="./services/services_dashboard.php" style="">Services</a></td>
        <td><a href="./contact/index.php" style="">Contact</a></td>
        <td><a href="./utilisateurs/index.php" style="">Utilisateurs</a></td>
    </tr>
</table>
