<?php
// Informations de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supercar";

// Créer une connexion
$bdd = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($bdd->connect_error) {
    die("Connexion échouée : " . $bdd->connect_error);
}

// Encodage des données en UTF-8 (important pour les accents)
$bdd->set_charset("utf8");
?>
